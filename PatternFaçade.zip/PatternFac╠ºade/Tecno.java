
public class Tecno implements Boutique {

	public void modele() {
		System.out.println(" Tecno Camon 17 ");
		
	}

	public void prix() {
		 System.out.println(" 93.000 FCFA");
		
	}

}
