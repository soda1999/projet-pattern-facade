
public class Iphone implements Boutique {

	@Override
	public void modele() {
		System.out.println(" Iphone 12 PRO MAX");
		
	}

	@Override
	public void prix() {
	   System.out.println(" 740.000 FCFA ");
		
	}

}
