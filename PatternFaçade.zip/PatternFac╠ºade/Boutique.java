
public interface Boutique {
	
	
	public void modele();
	
	public void prix();

}
