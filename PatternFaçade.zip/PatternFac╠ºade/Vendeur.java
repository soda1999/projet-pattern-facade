
public class Vendeur {
	private Boutique iphone;
	private Boutique samsung;
	private Boutique wiko;
	private Boutique tecno;

	public Vendeur(){
		iphone= new Iphone();
		samsung=new Samsung();
		wiko=new Wiko();
		tecno=new Tecno();		
	}

	public void iphoneVend(){	
		iphone.modele();
		iphone.prix();	
	}
	
    public void samsungVend(){
		samsung.modele();
		samsung.prix();
	}


   public void wikoVend(){
	wiko.modele();
	wiko.prix();	
}

 public void tecnoVend(){	
	tecno.modele();
	tecno.prix();	
}
	

}
