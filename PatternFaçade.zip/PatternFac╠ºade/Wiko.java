
public class Wiko implements Boutique {


	public void modele() {
		System.out.println(" Wiko Power U20  ");
		
	}
	public void prix() {
		 System.out.println(" 110.000 FCFA");
		
	}

}
