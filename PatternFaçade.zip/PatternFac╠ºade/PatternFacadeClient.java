import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class PatternFacadeClient {

	private static int  choix;
	
	
	
	public static void main(String args[]) throws NumberFormatException, IOException{
		
		
		do{		
			System.out.print("***************** Boutique de Vente de Telephones portables **************\n");
			System.out.print("            1. IPHONE              \n");
			System.out.print("            2. SAMSUNG             \n");
			System.out.print("            3. WIKO            \n");
			System.out.print("            4. Tecno.                     \n");
			System.out.print("            5. Exit.                     \n");
			System.out.print("Entrer votre choix: ");
			
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in)); 
			
			choix=Integer.parseInt(br.readLine());
			
			Vendeur vend =new Vendeur();
			
			switch (choix) {
			case 1:
				
				{ 
			      vend.iphoneVend();	 
			    }
				break;
				
	        case 2:
				
				{
				  vend.samsungVend();		     
			    }
				break;	
				
	        case 3:
	        	
	            {	
	             vend.wikoVend();	    
	            }
				break;	

			case 4:
			
	            {	
	             vend.tecnoVend();		    
	            }
				break;
				

			default:
			{  
				System.out.println("Rien Acheté");
				
			}		
				return;
			}
			
	  }while(choix!=5);
			
   }
			
}
	
	
	
	
