
public class Samsung implements Boutique {

	
	public void modele() {
		System.out.println(" Samsung Galaxy A71  ");
		
	}
	public void prix() {
		 System.out.println(" 214.000 FCFA");
		
	}

}
